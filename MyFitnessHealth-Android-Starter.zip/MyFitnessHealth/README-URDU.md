# My Fitness & Health — ابتدائی Android ورژن

اس ابتدائی ورژن میں:
- Android کے hardware TYPE_STEP_COUNTER سے قدم گننے کی کوشش
- Foreground service اور مستقل notification
- روزانہ قدموں کا سادہ کاؤنٹر
- پانی کے گلاس (250 ml) کا دستی اندراج
- وزن محفوظ کرنا
- بنیادی offline local storage

## اہم حدود
1. ہر فون میں hardware step-counter sensor نہیں ہوتا۔
2. Android/Oppo کی battery optimization سروس کو روک سکتی ہے۔ پہلے اپنے فون پر ٹیسٹ کریں اور ضرورت ہو تو Battery settings میں اس ایپ کے لیے background activity کی اجازت دیں۔
3. قدموں کی گنتی کے لیے Activity Recognition اور Android 13+ پر Notifications کی اجازت درکار ہے۔
4. یہ ابھی ابتدائی MVP ہے؛ کیلوریز، فاصلے، workouts، BMI، اردو/انگلش مکمل ترجمہ، goals، charts اور backup اگلے مراحل میں شامل ہوں گے۔
5. روزانہ reset اس وقت ہوگا جب ایپ کو اس دن کا پہلا sensor event ملے۔ فون restart ہونے یا service بند ہونے کی صورت میں sensor cumulative count کا baseline دوبارہ قائم ہوسکتا ہے؛ اسے مکمل طبی یا صحت کی پیمائش نہ سمجھیں۔

## APK بنانے کا طریقہ
اس ZIP کو GitHub repository میں upload کریں۔ `.github/workflows/build-apk.yml` خودکار build workflow فراہم کرتی ہے:
- GitHub میں repository کھولیں
- Actions ٹیب میں `Build My Fitness Health APK` منتخب کریں
- Run workflow دبائیں
- مکمل ہونے پر Artifacts سے `MyFitnessHealth-debug-apk` ڈاؤن لوڈ کریں

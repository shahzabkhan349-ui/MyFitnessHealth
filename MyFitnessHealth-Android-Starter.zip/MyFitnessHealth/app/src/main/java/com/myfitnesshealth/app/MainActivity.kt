package com.myfitnesshealth.app

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.widget.*
import android.graphics.Color
import android.content.Context

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("fitness", Context.MODE_PRIVATE) }
    private lateinit var stepsText: TextView
    private lateinit var waterText: TextView
    private lateinit var weightText: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestNeededPermissions()
        buildDashboard()
    }

    private fun requestNeededPermissions() {
        val needed = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= 29 &&
            checkSelfPermission(Manifest.permission.ACTIVITY_RECOGNITION) != PackageManager.PERMISSION_GRANTED)
            needed.add(Manifest.permission.ACTIVITY_RECOGNITION)
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            needed.add(Manifest.permission.POST_NOTIFICATIONS)
        if (needed.isNotEmpty()) requestPermissions(needed.toTypedArray(), 10)
        else startTracker()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, results: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, results)
        if (requestCode == 10 && results.isNotEmpty() && results.all { it == PackageManager.PERMISSION_GRANTED }) {
            startTracker()
        }
    }

    private fun startTracker() {
        val i = Intent(this, StepCounterService::class.java)
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
    }

    private fun buildDashboard() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 30, 24, 24)
            setBackgroundColor(Color.rgb(11, 19, 43))
        }
        fun title(t: String, size: Float, color: Int = Color.WHITE) =
            TextView(this).apply { text = t; textSize = size; setTextColor(color); gravity = Gravity.CENTER }
        root.addView(title("MY FITNESS & HEALTH", 22f))
        root.addView(title("Daily wellness dashboard", 14f, Color.LTGRAY))
        stepsText = title("0\nSTEPS TODAY", 30f)
        val stepsCard = card()
        stepsCard.addView(stepsText)
        root.addView(stepsCard)
        waterText = title("Water: ${prefs.getInt("water", 0)} ml", 20f)
        val waterCard = card()
        waterCard.addView(waterText)
        val waterBtn = Button(this).apply {
            text = "+ 250 ml water"
            setOnClickListener {
                val n = prefs.getInt("water", 0) + 250
                prefs.edit().putInt("water", n).apply()
                waterText.text = "Water: $n ml"
            }
        }
        waterCard.addView(waterBtn)
        root.addView(waterCard)
        weightText = title("Weight: ${prefs.getString("weight", "—")} kg", 18f)
        val weightCard = card()
        weightCard.addView(weightText)
        val weightInput = EditText(this).apply {
            hint = "Enter weight in kg"
            inputType = 8194
            setSingleLine(true)
        }
        weightCard.addView(weightInput)
        weightCard.addView(Button(this).apply {
            text = "Save weight"
            setOnClickListener {
                val v = weightInput.text.toString().trim()
                if (v.toFloatOrNull() != null) {
                    prefs.edit().putString("weight", v).apply()
                    weightText.text = "Weight: $v kg"
                    weightInput.text.clear()
                } else Toast.makeText(this@MainActivity, "Enter a valid weight", Toast.LENGTH_SHORT).show()
            }
        })
        root.addView(weightCard)
        root.addView(Button(this).apply {
            text = "Start step tracking"
            setOnClickListener { startTracker(); Toast.makeText(this@MainActivity, "Step tracking service started", Toast.LENGTH_SHORT).show() }
        })
        root.addView(title("Steps update when the phone detects movement. Keep the notification enabled.", 12f, Color.LTGRAY))
        setContentView(ScrollView(this).apply { addView(root) })
        refreshSteps()
    }

    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(18, 18, 18, 18)
        setBackgroundColor(Color.rgb(25, 39, 68))
        val p = LinearLayout.LayoutParams(-1, -2)
        p.setMargins(0, 22, 0, 0)
        layoutParams = p
    }

    private fun refreshSteps() {
        val count = prefs.getInt("today_steps", 0)
        stepsText.text = "$count\nSTEPS TODAY"
    }

    override fun onResume() {
        super.onResume()
        if (::stepsText.isInitialized) refreshSteps()
    }
}
